# Pré-Projeto: Sistema de Gestão de Professores e Escolas
## Secretaria Municipal de Educação de Canoas — MVP

**Versão:** 2.0
**Data:** Julho 2026
**Responsável:** Felipe
**Status:** Pré-projeto revisado — pronto para desenvolvimento

---

## 1. Visão Geral e Problema Atual

A Secretaria Municipal de Educação de Canoas administra **44 escolas** e mais de **2.000 professores**, controlados hoje por planilhas no Google Drive (Google Sheets), uma por escola, sem comunicação entre elas.

### 1.1 Problemas identificados no controle atual

- **Múltiplas planilhas desconectadas**: cada escola preenche separadamente, sem cruzamento de dados.
- **Erros de padronização**: cores, termos e formatos inconsistentes entre diretores/supervisores.
- **Sem controle automático de carga horária**: não há cálculo de quantos períodos cada professor está cumprindo — professores podem estar abaixo da carga obrigatória sem que ninguém perceba.
- **Escolas com vagas descobertas** sem visibilidade centralizada.
- **Ausências sem registro de cobertura**: quando um professor falta, a substituição é informal e não documentada.
- **Risco de fraude**: sem rastreabilidade de quem está efetivamente em sala.
- **Professor em mais de uma escola**: impossível controlar CCH (Complementação de Carga Horária) por planilhas separadas.

### 1.2 Por que um sistema dedicado

- Cálculo automático de carga horária (períodos cumpridos vs. obrigatórios).
- Validação de dados por listas controladas — sem digitação livre onde não deve haver.
- Visão consolidada para a Secretaria; visão restrita por escola para os Diretores.
- Rastreabilidade de alocações, substituições e afastamentos.
- Controle de CCH entre escolas em banco único.

---

## 2. Objetivo do MVP

Construir uma primeira versão funcional para uso real da Secretaria, substituindo o controle manual por planilhas. O MVP será testado com um grupo piloto de escolas antes de expandir para as 44.

### 2.1 Escopo do MVP — o que ENTRA

- Cadastro de escolas, turmas, professores, disciplinas e cargos/funções.
- Matriz curricular com parte fixa (global) e parte configurável por escola (projetos).
- Lotação de professores por escola, turno e tipo (principal ou CCH).
- Alocação de professores às turmas/disciplinas pela Diretora.
- Cálculo automático de carga horária cumprida vs. obrigatória (todos os vínculos somados).
- Alertas de carga horária incompleta e de vaga descoberta por turma/disciplina.
- Registro simples de afastamento (status + datas, sem motivo médico).
- Registro simples de alocação temporária (cobertura de vaga ou substituição).
- Login por perfil: Secretaria Central, Diretora (por escola), Visualização.
- Painel consolidado para a Secretaria (todas as escolas).
- Painel restrito para a Diretora (apenas sua escola).

### 2.2 Critério de sucesso do MVP

O MVP é bem-sucedido se, para o grupo piloto, a Secretaria conseguir:
- Substituir o preenchimento manual do quadro de organização.
- Identificar automaticamente professores com carga horária incompleta.
- Identificar automaticamente turmas/disciplinas sem professor alocado.
- Controlar CCH entre escolas sem planilhas paralelas.

---

## 3. Regras de Negócio

### 3.1 Cargas horárias e períodos obrigatórios

| Carga horária | Períodos obrigatórios/semana | Observação |
|---|---|---|
| 40h | 26 períodos | Carga máxima por matrícula |
| 20h | 13 períodos | Carga mínima por matrícula |
| 10h (CCH) | 6 períodos | Complementação — só para quem já tem 20h; quem já tem 40h não pode ter CCH |

**Regra de CCH:** um professor pode distribuir sua carga entre mais de uma escola.
Exemplos válidos:
- 20h em escola A + 10h em escola B = 30h total / 19 períodos
- 20h em escola A + 20h em escola B = 40h total / 26 períodos
- 25h em escola A + 15h em escola B = 40h total / 26 períodos

> O sistema deve somar os períodos de **todas as lotações** do professor para calcular a carga total cumprida, independente de quantas escolas estejam envolvidas.

### 3.2 Tipos de servidor

#### Professores (dão aula)

| Tipo | Descrição |
|---|---|
| **PEB1 — Regente** | Professor dos Anos Iniciais (1º ao 5º). Responsável pelos 13 períodos de LP, ER, M, C, H, G da turma. |
| **PEB2 — Especialista Anos Finais** | Professor dos Anos Finais (6º ao 9º). Leciona disciplina única. |
| **Especialista Anos Iniciais** | Atende múltiplas turmas em disciplina única: EF, PPA, PLL, TICs ou Arte. |
| **EJA** | Estrutura própria — nem toda escola possui turno noturno. |

#### Cargos e Funções (não dão aula regularmente — períodos = 0)

| Cargo/Função | Observação |
|---|---|
| Diretor | Não dá aula. Em situações excepcionais pode cobrir ausência (alocação temporária). |
| Vice-Diretor | Idem. |
| Supervisor | Não dá aula. |
| Orientador | Não dá aula. |
| Secretaria | Não dá aula. |
| TEB (Técnico em Educação Básica) | Não dá aula. Pode ter 20h ou 40h. |
| Biblioteca | Não dá aula. Pode ter 20h ou 40h. Pode ser professor readaptado. |
| Laboratório de Aprendizagem | Não dá aula. Pode ter 20h ou 40h. Pode ser professor readaptado. |
| Sala de Recursos (SRM/AEE) | Não dá aula regular. Atendimento especializado. |
| Estagiário | Não dá aula. Carga variável (ex: 30h). |

#### Assessor Pedagógico — caso especial

- Normalmente não tem alocação regular em turmas (períodos = 0).
- Quando há vaga permanente sem titular, pode assumir alocação fixa temporária naquelas turmas — registrada como **alocação temporária** no sistema, igual a qualquer outra cobertura.
- A alocação temporária permanece até a vaga ser preenchida por professor titular.
- Pode também cobrir ausências pontuais (atestados curtos).

#### Professor Readaptado

- Professor afastado permanentemente de sala de aula por motivo de saúde (decisão de junta médica), realocado em função administrativa (secretaria, biblioteca, etc.).
- Status próprio no cadastro: `readaptado`.
- Não tem períodos obrigatórios de aula.

### 3.3 Status funcional do professor

| Status | Descrição |
|---|---|
| `ativo` | Em exercício normal |
| `afastado` | Atestado ou licença temporária — data início/fim registradas, **sem motivo médico** |
| `readaptado` | Realocado permanentemente em função administrativa por junta médica |
| `reducao_de_carga` | Carga horária reduzida por decisão da Secretaria — períodos definidos caso a caso |
| `excedente` | Professor sem vaga fixa no momento — controlado pela Secretaria |
| `a_disposicao` | Professor cedido/deslocado temporariamente |

### 3.4 Estrutura pedagógica por etapa

| Etapa | Anos | Modelo |
|---|---|---|
| Anos Iniciais | 1º ao 5º | Regente (13 períodos) + Especialistas (EF=2, Projetos=5) = 20 períodos/turma |
| Anos Finais | 6º ao 9º | Professor por disciplina única = 20 períodos/turma |
| EJA | Noite | Estrutura própria — apenas escolas com turno noturno ativo |

**Composição dos 20 períodos semanais por turma — Anos Iniciais:**
- **13 períodos → Regente:** LP(3) + ER(1) + M(3) + C(2) + H(2) + G(2)
- **2 períodos → Educação Física** (especialista PEB2-EF)
- **5 períodos → Projetos** (distribuição configurável pela Diretora — ver 3.5)

**Composição dos 20 períodos semanais por turma — Anos Finais (6º ao 9º):**

| Disciplina | Sigla | Períodos |
|---|---|---|
| Língua Portuguesa | LP | 4 |
| Língua Inglesa | LI | 2 |
| Matemática | M | 4 |
| Ciências | C | 2 |
| História | H | 2 |
| Geografia | G | 2 |
| Educação Física | EF | 2 |
| Ensino Religioso | ER | 1 |
| Arte | A | 1 |
| **Total** | | **20** |

### 3.5 Matriz curricular — parte fixa e parte configurável

A matriz é baseada na **Portaria 2289/2021** e é referência para todas as 44 escolas.

**Parte fixa (igual para todas as escolas):**
- Anos Finais (6º ao 9º): todos os períodos são fixos conforme tabela acima.
- Anos Iniciais: LP, ER, M, C, H, G (regente) e EF são fixos.

**Parte configurável por escola (decisão da Diretora):**
- Os **5 períodos de Projetos** dos Anos Iniciais são distribuídos entre PPA, PLL, TICs e Arte.
- **Regra:** cada um dos 4 projetos deve ter no mínimo 1 período. O 5º período restante é alocado em qualquer um dos quatro, a critério da Diretora.
- Exemplo válido: PPA=2, PLL=1, TICs=1, Arte=1 (total=5 ✅)
- Exemplo inválido: PPA=3, PLL=1, TICs=1, Arte=0 (Arte com zero ❌)

> A configuração dos projetos é editável pela Diretora diretamente no sistema — reflete a autonomia pedagógica da escola. Alterações são raras (geralmente apenas no início do ano letivo) e cada escola pode ter configuração diferente por ano. Toda alteração registra automaticamente `updated_at` (data/hora) e `updated_by` (usuário responsável) para rastreabilidade.

### 3.6 Lotação e turno por escola

Um professor pode estar lotado em mais de uma escola. Cada vínculo de lotação tem turno definido, evitando conflito de horário.

```
Exemplo:
Professor X — PEB1 — 40h total
  Lotação 1: Escola A — turno manhã — 20h (principal)
  Lotação 2: Escola B — turno tarde — 20h (CCH)
```

A Secretaria é responsável por criar e gerenciar os vínculos de lotação. A Diretora só enxerga professores com lotação ativa na sua escola.

### 3.7 Cálculo de carga horária

```
períodos_cumpridos(professor) =
  SOMA(períodos de todas as alocações regulares ativas)
  + SOMA(períodos de todas as alocações temporárias ativas)
  — em todas as escolas onde está lotado

saldo = períodos_obrigatórios_totais - períodos_cumpridos

SE saldo > 0  → ALERTA: carga horária incompleta
SE saldo < 0  → ALERTA: carga horária excedida (verificar inconsistência)
SE saldo = 0  → carga horária completa ✅
```

> `períodos_obrigatórios_totais` é a soma de todas as lotações do professor.
> Exemplo: professor com 20h na escola A + 10h CCH na escola B tem 19 períodos obrigatórios totais.

### 3.8 Alocação temporária (cobertura de vaga ou substituição)

Usado em dois cenários:

**Cenário 1 — Vaga sem titular:** professor (geralmente Assessor Pedagógico) assume turmas de uma vaga em aberto até contratação de titular.

**Cenário 2 — Substituição por afastamento:** professor, assessor, ou qualquer servidor disponível (inclusive Diretor em último caso) cobre ausência pontual.

Em ambos os casos o registro é idêntico — alocação com flag `temporaria = true` e datas de vigência. Não há fluxo de aprovação no MVP.

---

## 4. Modelo de Dados

### 4.1 Entidades

```
ESCOLA
  id
  nome
  turnos_ativos[]       -- ['manha', 'tarde', 'noite']
  possui_eja            -- booleano

DISCIPLINA
  id
  nome
  sigla                 -- LP, M, H, G, C, EF, ER, A, LI, PPA, PLL, TICs
  editavel_por          -- 'admin' (apenas admin pode inserir novas)

CARGO_FUNCAO            -- separado de DISCIPLINA
  id
  nome                  -- Diretor, Vice-Diretor, Supervisor, Orientador,
                        -- Secretaria, TEB, Biblioteca, Lab, SRM, Assessor
                        -- Pedagógico, Estagiário, Readaptado

MATRIZ_CURRICULAR_GLOBAL   -- parte fixa, igual para todas as escolas
  id
  etapa                 -- 'iniciais' | 'finais' | 'eja'
  ano_escolar           -- 1 a 9, ou identificador EJA
  disciplina_id
  periodos_semana

MATRIZ_PROJETOS_ESCOLA     -- parte configurável por escola (projetos anos iniciais)
  id
  escola_id
  disciplina_id         -- PPA, PLL, TICs ou Arte
  periodos_semana       -- mínimo 1, soma dos 4 = 5

PROFESSOR
  id
  matricula             -- único, usado como ID de negócio
  nome
  area_concurso         -- PEB1, PEB2, Especialista, TEB, Área2, etc.
  cargo_funcao_id       -- se em função administrativa; nulo se professor ativo
  disciplina_principal_id
  status                -- ativo | afastado | readaptado | reducao_de_carga
                        --        | excedente | a_disposicao
  data_inicio_afastamento
  data_fim_afastamento  -- pode ser nulo se indeterminado

LOTACAO_PROFESSOR          -- vínculo professor ↔ escola (pode ser múltiplo)
  id
  professor_id
  escola_id
  carga_horaria         -- 10 | 20 | 40
  tipo                  -- 'principal' | 'cch'
  turno                 -- 'manha' | 'tarde' | 'noite' | 'integral'
  ativo                 -- booleano

TURMA
  id
  escola_id
  ano_escolar           -- 1 a 9, ou identificador EJA
  turno                 -- manha | tarde | noite
  identificador         -- A, B, C...

ALOCACAO
  id
  professor_id
  turma_id
  disciplina_id
  periodos              -- quantidade de períodos/semana nesta alocação
  tipo                  -- 'regular' | 'temporaria'
  data_inicio           -- obrigatório para temporária
  data_fim              -- pode ser nulo (temporária sem prazo definido)
  ativo                 -- booleano

USUARIO
  id
  nome
  login
  senha_hash            -- bcrypt, nunca texto puro
  perfil                -- 'admin' | 'secretaria_central' | 'diretor' | 'visualizacao'
  escola_id             -- nulo para admin e secretaria_central
```

### 4.2 Relacionamentos principais

- `ESCOLA` → N `TURMA`
- `ESCOLA` → N `LOTACAO_PROFESSOR` ← `PROFESSOR`
- `TURMA` → N `ALOCACAO` ← `PROFESSOR`
- `ALOCACAO` → 1 `DISCIPLINA`
- `MATRIZ_CURRICULAR_GLOBAL` define os períodos esperados por disciplina/ano
- `MATRIZ_PROJETOS_ESCOLA` sobrescreve os períodos dos projetos para cada escola
- `CARGO_FUNCAO` é atributo do professor quando em função administrativa — separado de `DISCIPLINA`

---

## 5. Perfis de Acesso e Permissões

| Perfil | O que pode fazer |
|---|---|
| **Admin** | Tudo. Cadastra escolas, professores, disciplinas, cargos. Gerencia usuários. |
| **Secretaria Central** | Gerencia lotações (vincula professor ↔ escola). Registra afastamentos. Configura matriz de projetos por escola. Visualiza painel consolidado de todas as escolas. |
| **Diretora** | Aloca professores às turmas da sua escola (apenas entre os lotados nela). Registra alocações temporárias. Configura distribuição dos projetos (PPA, PLL, TICs, Arte) da sua escola. Visualiza painel da sua escola. Não acessa dados de outras escolas. |
| **Visualização** | Somente leitura. Para supervisores ou outros perfis de consulta. |

> **Regra crítica de segurança:** a restrição de acesso por escola é implementada no **backend (API)**, nunca apenas no frontend. Um Diretor não pode acessar dados de outra escola nem manipulando URLs.

---

## 6. Segurança e Privacidade dos Dados (LGPD)

### 6.1 Princípio de minimização de dados

O sistema armazena **apenas o estritamente necessário**:

- **Afastamentos:** apenas status e datas — **nunca o motivo médico**.
- **Readaptação:** apenas o status — sem diagnóstico ou laudo.
- **Identificação:** matrícula e nome. Sem CPF, endereço ou telefone no MVP.

### 6.2 Medidas técnicas obrigatórias

- Senhas com hash bcrypt — nunca texto puro.
- Comunicação exclusivamente via HTTPS.
- Controle de acesso por escola implementado no backend.
- Backups automáticos gerenciados pelo provedor (Supabase).
- Sem campos de texto livre para dados sensíveis.

---

## 7. Stack Tecnológica e Hospedagem

Mesma stack do BlendPro Platform — já dominada pelo responsável técnico.

| Camada | Tecnologia |
|---|---|
| Frontend | React + Vite |
| Backend | Node.js + Express (API REST) |
| Banco de dados | PostgreSQL — Supabase |
| Autenticação | JWT |
| Hospedagem backend | Render |
| Hospedagem frontend | Vercel |

---

## 8. Fluxos Principais

### 8.1 Cadastro e lotação (Secretaria / Admin)

1. Admin cadastra a escola e suas turmas ativas (turnos, anos, identificadores).
2. Admin cadastra o professor (matrícula, nome, área, disciplina principal, status).
3. Secretaria cria a lotação: vincula professor → escola, define carga horária, tipo (principal/CCH) e turno.
4. Se CCH: cria segundo vínculo de lotação para a segunda escola, turno diferente.

### 8.2 Alocação de turmas (Diretora)

1. Diretora acessa sua escola — vê lista de professores lotados nela.
2. Para cada turma, seleciona qual professor leciona qual disciplina e quantos períodos.
3. Sistema valida: disciplina disponível na matriz, professor com lotação ativa naquele turno.
4. Sistema recalcula automaticamente o saldo de carga horária do professor.

### 8.3 Afastamento e cobertura

1. Secretaria ou Diretora registra afastamento: professor → status `afastado`, datas, sem motivo.
2. Diretora cria alocação temporária: define quem cobre, qual turma/disciplina, período.
3. Sistema registra como `tipo = temporaria` com data de início. Data de fim pode ser aberta.
4. Quando professor volta ou vaga é preenchida: alocação temporária encerrada, alocação regular restaurada.

### 8.4 Alertas automáticos

| Alerta | Condição |
|---|---|
| Carga horária incompleta | `saldo > 0` para qualquer professor ativo |
| Carga horária excedida | `saldo < 0` — possível inconsistência |
| Vaga descoberta | Turma com disciplina sem nenhuma alocação ativa |
| Professor afastado sem cobertura | Professor afastado com turmas sem alocação temporária |

---

## 9. Fora de Escopo no MVP

- App mobile nativo.
- Integração com RH/folha de pagamento da prefeitura.
- Fluxo de aprovação ou notificação de substituições.
- Log de auditoria detalhado (histórico de alterações).
- Geração de relatórios oficiais para a prefeitura.
- Ferramenta de importação de planilhas (planejada para fase pós-MVP, após banco estável).
- Apresentação formal à TI da prefeitura.
- Multi-tenant para outros municípios.

---

## 10. Ordem de Desenvolvimento Recomendada

Construção incremental — cada etapa deve estar funcionando antes de avançar.

| Etapa | O que construir |
|---|---|
| 1 | Banco de dados: schema SQL completo + seed (matriz curricular, disciplinas, cargos) |
| 2 | API: CRUD de escolas e turmas |
| 3 | API: CRUD de professores e lotações |
| 4 | API: cálculo de carga horária (lógica central) |
| 5 | API: CRUD de alocações + recálculo automático |
| 6 | API: afastamentos e alocações temporárias |
| 7 | API: autenticação JWT e controle de perfis |
| 8 | Frontend: telas de cadastro (escolas, professores, lotações) |
| 9 | Frontend: painel da Diretora (alocação de turmas) |
| 10 | Frontend: painel da Secretaria (visão consolidada + alertas) |

> **Regra:** não comece pelo frontend bonito. O banco e a lógica de carga horária precisam estar corretos primeiro — são o coração do sistema.

---

## 11. Pendências e Decisões em Aberto

| Item | Status |
|---|---|
| Migração de dados das 44 escolas | Planejada para pós-desenvolvimento. Ferramenta de importação a construir após banco estável. |
| Definição do grupo piloto de escolas | A definir com a Secretaria antes do primeiro deploy. |
| Controle de ano letivo | Não discutido — o sistema controla o ano corrente ou mantém histórico? |
| EJA — regras específicas | Não detalhadas. Precisa de reunião específica antes de implementar. |

---

*Versão 2.0 — Documento vivo, sujeito a revisão conforme o desenvolvimento avança.*

---

## Atualizações v2.1 (Julho 2026)

### Regras adicionais validadas

**EJA — sem restrição de tipo de professor:**
No turno noturno (EJA), não há restrição de PEB1/PEB2 para lecionar disciplinas. Qualquer professor pode assumir múltiplas disciplinas conforme necessidade da escola. O sistema não deve bloquear alocações de PEB2 em múltiplas disciplinas no EJA.

**Carga horária de 30h:**
Identificada na EMEF Rio de Janeiro (professora Fernanda Pimentel Vianna). Hipótese: erro de digitação na planilha. O modelo não prevê 30h como carga válida (apenas 10h, 20h e 40h). A verificar no momento da migração de dados dessa escola.

**Escolas do piloto definidas:**
1. EMEF Carlos Drummond de Andrade
2. EMEF Paulo VI
3. EMEF Santos Dumont

**Justificativa da escolha:**
- Carlos Drummond: maior complexidade — CCH, readaptados, excedentes, assessores fixos, muitas turmas.
- Paulo VI: complexidade média — tem EJA, redução de carga, sem CCH. Valida o caso intermediário.
- Santos Dumont: EJA completo (Alfa/Pós + M1 a M4), CCH entre múltiplas escolas, professor em processo de aposentadoria.
