-- ============================================================
-- SISTEMA DE GESTÃO DE PROFESSORES E ESCOLAS
-- Secretaria Municipal de Educação de Canoas
-- Schema v1.0 — Julho 2026
-- ============================================================

-- ============================================================
-- PARTE 1 — TABELAS DE REFERÊNCIA
-- ============================================================

CREATE TABLE disciplinas (
  id        SERIAL PRIMARY KEY,
  nome      VARCHAR(50) NOT NULL,
  sigla     VARCHAR(10) NOT NULL UNIQUE,
  ativo     BOOLEAN DEFAULT true
);

CREATE TABLE cargos_funcoes (
  id        SERIAL PRIMARY KEY,
  nome      VARCHAR(50) NOT NULL UNIQUE,
  ativo     BOOLEAN DEFAULT true
);

-- ============================================================
-- PARTE 2 — ESCOLAS
-- ============================================================

CREATE TABLE escolas (
  id            SERIAL PRIMARY KEY,
  nome          VARCHAR(100) NOT NULL,
  turno_manha   BOOLEAN DEFAULT false,
  turno_tarde   BOOLEAN DEFAULT false,
  turno_noite   BOOLEAN DEFAULT false,
  possui_eja    BOOLEAN DEFAULT false,
  ativo         BOOLEAN DEFAULT true
);

-- ============================================================
-- PARTE 3 — PROFESSORES
-- ============================================================

CREATE TABLE professores (
  id                        SERIAL PRIMARY KEY,
  matricula                 VARCHAR(20) NOT NULL UNIQUE,
  nome                      VARCHAR(100) NOT NULL,
  area_concurso             VARCHAR(50),
  cargo_funcao_id           INTEGER REFERENCES cargos_funcoes(id),
  disciplina_principal_id   INTEGER REFERENCES disciplinas(id),
  carga_horaria_contratual  INTEGER NOT NULL
                            CHECK (carga_horaria_contratual IN (10, 20, 40)),
  tipo_vinculo              VARCHAR(15) NOT NULL DEFAULT 'concursado'
                            CHECK (tipo_vinculo IN ('concursado', 'contratado')),
  data_fim_contrato         DATE,
  status                    VARCHAR(20) NOT NULL DEFAULT 'ativo'
                            CHECK (status IN (
                              'ativo',
                              'afastado',
                              'readaptado',
                              'reducao_de_carga',
                              'excedente',
                              'a_disposicao'
                            )),
  data_inicio_afastamento   DATE,
  data_fim_afastamento      DATE,
  ano_letivo                INTEGER NOT NULL DEFAULT 2026,
  criado_em                 TIMESTAMP DEFAULT NOW(),
  atualizado_em             TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- PARTE 4 — LOTAÇÕES (professor ↔ escola)
-- ============================================================

CREATE TABLE lotacoes (
  id              SERIAL PRIMARY KEY,
  professor_id    INTEGER NOT NULL REFERENCES professores(id),
  escola_id       INTEGER NOT NULL REFERENCES escolas(id),
  carga_horaria   INTEGER NOT NULL CHECK (carga_horaria IN (10, 20, 40)),
  tipo            VARCHAR(15) NOT NULL CHECK (tipo IN ('principal', 'cch')),
  turno           VARCHAR(10) NOT NULL
                  CHECK (turno IN ('manha', 'tarde', 'noite', 'integral')),
  ativo           BOOLEAN DEFAULT true,
  ano_letivo      INTEGER NOT NULL DEFAULT 2026,
  criado_em       TIMESTAMP DEFAULT NOW(),
  atualizado_em   TIMESTAMP DEFAULT NOW(),

  -- Professor não pode ter duas lotações no mesmo turno no mesmo ano
  UNIQUE (professor_id, turno, ano_letivo)
);

-- ============================================================
-- PARTE 5 — TURMAS
-- ============================================================

CREATE TABLE turmas (
  id            SERIAL PRIMARY KEY,
  escola_id     INTEGER NOT NULL REFERENCES escolas(id),
  ano_escolar   VARCHAR(15) NOT NULL CHECK (ano_escolar IN (
                  '1', '2', '3', '4', '5',
                  '6', '7', '8', '9',
                  'eja_alfa', 'eja_pos', 'eja_alfa_pos',
                  'eja_m1', 'eja_m2', 'eja_m1_m2',
                  'eja_m3', 'eja_m4'
                )),
  turno         VARCHAR(10) NOT NULL
                CHECK (turno IN ('manha', 'tarde', 'noite')),
  identificador VARCHAR(5) NOT NULL,
  ativo         BOOLEAN DEFAULT true,
  ano_letivo    INTEGER NOT NULL DEFAULT 2026,
  criado_em     TIMESTAMP DEFAULT NOW(),

  UNIQUE (escola_id, ano_escolar, turno, identificador, ano_letivo)
);

-- ============================================================
-- PARTE 6 — MATRIZ CURRICULAR
-- ============================================================

-- Parte fixa — igual para todas as escolas
CREATE TABLE matriz_curricular_global (
  id              SERIAL PRIMARY KEY,
  etapa           VARCHAR(10) NOT NULL
                  CHECK (etapa IN ('iniciais', 'finais', 'eja')),
  ano_escolar     VARCHAR(15) NOT NULL,
  disciplina_id   INTEGER NOT NULL REFERENCES disciplinas(id),
  periodos_semana INTEGER NOT NULL CHECK (periodos_semana > 0),

  UNIQUE (ano_escolar, disciplina_id)
);

-- Parte configurável — projetos por escola (PPA, PLL, TICs, Arte)
-- Regra: cada projeto mínimo 1 período, soma dos 4 = 5
-- Validação da soma feita no backend
CREATE TABLE matriz_projetos_escola (
  id              SERIAL PRIMARY KEY,
  escola_id       INTEGER NOT NULL REFERENCES escolas(id),
  ano_escolar     VARCHAR(15) NOT NULL,
  disciplina_id   INTEGER NOT NULL REFERENCES disciplinas(id),
  periodos_semana INTEGER NOT NULL CHECK (periodos_semana >= 1),
  ano_letivo      INTEGER NOT NULL DEFAULT 2026,
  atualizado_em   TIMESTAMP DEFAULT NOW(),
  atualizado_por  INTEGER REFERENCES usuarios(id),

  UNIQUE (escola_id, ano_escolar, disciplina_id, ano_letivo)
);

-- ============================================================
-- PARTE 7 — ALOCAÇÕES (professor → turma → disciplina)
-- ============================================================

CREATE TABLE alocacoes (
  id            SERIAL PRIMARY KEY,
  professor_id  INTEGER NOT NULL REFERENCES professores(id),
  turma_id      INTEGER NOT NULL REFERENCES turmas(id),
  disciplina_id INTEGER NOT NULL REFERENCES disciplinas(id),
  periodos      INTEGER NOT NULL CHECK (periodos > 0),
  tipo          VARCHAR(15) NOT NULL DEFAULT 'regular'
                CHECK (tipo IN ('regular', 'temporaria')),
  -- motivo obrigatório quando tipo = 'temporaria' (validado no backend)
  motivo        VARCHAR(20)
                CHECK (motivo IN ('vaga_aberta', 'afastamento')),
  data_inicio   DATE,
  data_fim      DATE,
  ativo         BOOLEAN DEFAULT true,
  ano_letivo    INTEGER NOT NULL DEFAULT 2026,
  criado_em     TIMESTAMP DEFAULT NOW(),
  atualizado_em TIMESTAMP DEFAULT NOW(),

  -- Uma turma só pode ter um professor por disciplina por ano
  UNIQUE (turma_id, disciplina_id, ano_letivo)
);

-- ============================================================
-- PARTE 8 — USUÁRIOS E AUDITORIA
-- ============================================================

CREATE TABLE usuarios (
  id          SERIAL PRIMARY KEY,
  nome        VARCHAR(100) NOT NULL,
  login       VARCHAR(50) NOT NULL UNIQUE,
  senha_hash  VARCHAR(255) NOT NULL,
  perfil      VARCHAR(20) NOT NULL
              CHECK (perfil IN (
                'admin',
                'secretaria_central',
                'diretor',
                'visualizacao'
              )),
  escola_id   INTEGER REFERENCES escolas(id),
  ativo       BOOLEAN DEFAULT true,
  criado_em   TIMESTAMP DEFAULT NOW()
);

CREATE TABLE log_auditoria (
  id              SERIAL PRIMARY KEY,
  usuario_id      INTEGER NOT NULL REFERENCES usuarios(id),
  acao            VARCHAR(10) NOT NULL
                  CHECK (acao IN ('criou', 'editou', 'removeu')),
  tabela          VARCHAR(50) NOT NULL,
  registro_id     INTEGER NOT NULL,
  dados_anterior  JSONB,
  criado_em       TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- SEED — DADOS DE REFERÊNCIA
-- ============================================================

-- Disciplinas
INSERT INTO disciplinas (nome, sigla) VALUES
  ('Língua Portuguesa', 'LP'),
  ('Língua Inglesa', 'LI'),
  ('Matemática', 'M'),
  ('Ciências', 'C'),
  ('História', 'H'),
  ('Geografia', 'G'),
  ('Educação Física', 'EF'),
  ('Ensino Religioso', 'ER'),
  ('Arte', 'A'),
  ('Projeto Pedagógico Alternativo', 'PPA'),
  ('Projeto Livro e Leitura', 'PLL'),
  ('Tecnologias da Informação e Comunicação', 'TICs');

-- Cargos e Funções
INSERT INTO cargos_funcoes (nome) VALUES
  ('Diretor'),
  ('Vice-Diretor'),
  ('Supervisor'),
  ('Orientador'),
  ('Secretaria'),
  ('TEB'),
  ('Biblioteca'),
  ('Laboratório de Aprendizagem'),
  ('Sala de Recursos'),
  ('Assessor Pedagógico'),
  ('Estagiário'),
  ('Readaptado');

-- Matriz Curricular Global — Anos Iniciais (1º ao 4º)
INSERT INTO matriz_curricular_global (etapa, ano_escolar, disciplina_id, periodos_semana)
SELECT 'iniciais', ano, d.id, p FROM (VALUES
  ('1', 'LP', 3), ('1', 'ER', 1), ('1', 'M', 3), ('1', 'C', 2),
  ('1', 'H', 2),  ('1', 'G', 2),  ('1', 'EF', 2),
  ('2', 'LP', 3), ('2', 'ER', 1), ('2', 'M', 3), ('2', 'C', 2),
  ('2', 'H', 2),  ('2', 'G', 2),  ('2', 'EF', 2),
  ('3', 'LP', 3), ('3', 'ER', 1), ('3', 'M', 3), ('3', 'C', 2),
  ('3', 'H', 2),  ('3', 'G', 2),  ('3', 'EF', 2),
  ('4', 'LP', 3), ('4', 'ER', 1), ('4', 'M', 3), ('4', 'C', 2),
  ('4', 'H', 2),  ('4', 'G', 2),  ('4', 'EF', 2),
  ('5', 'LP', 3), ('5', 'ER', 1), ('5', 'M', 3), ('5', 'C', 2),
  ('5', 'H', 2),  ('5', 'G', 2),  ('5', 'EF', 2)
) AS t(ano, sigla, p)
JOIN disciplinas d ON d.sigla = t.sigla;

-- Matriz Curricular Global — Anos Finais (6º ao 9º)
INSERT INTO matriz_curricular_global (etapa, ano_escolar, disciplina_id, periodos_semana)
SELECT 'finais', ano, d.id, p FROM (VALUES
  ('6', 'LP', 4), ('6', 'LI', 2), ('6', 'M', 4), ('6', 'C', 2),
  ('6', 'H', 2),  ('6', 'G', 2),  ('6', 'EF', 2), ('6', 'ER', 1), ('6', 'A', 1),
  ('7', 'LP', 4), ('7', 'LI', 2), ('7', 'M', 4), ('7', 'C', 2),
  ('7', 'H', 2),  ('7', 'G', 2),  ('7', 'EF', 2), ('7', 'ER', 1), ('7', 'A', 1),
  ('8', 'LP', 4), ('8', 'LI', 2), ('8', 'M', 4), ('8', 'C', 2),
  ('8', 'H', 2),  ('8', 'G', 2),  ('8', 'EF', 2), ('8', 'ER', 1), ('8', 'A', 1),
  ('9', 'LP', 4), ('9', 'LI', 2), ('9', 'M', 4), ('9', 'C', 2),
  ('9', 'H', 2),  ('9', 'G', 2),  ('9', 'EF', 2), ('9', 'ER', 1), ('9', 'A', 1)
) AS t(ano, sigla, p)
JOIN disciplinas d ON d.sigla = t.sigla;

-- Matriz Curricular Global — EJA
INSERT INTO matriz_curricular_global (etapa, ano_escolar, disciplina_id, periodos_semana)
SELECT 'eja', ano, d.id, p FROM (VALUES
  -- Alfa e Pós (16 períodos, sem LI)
  ('eja_alfa', 'LP', 4), ('eja_alfa', 'A', 1),  ('eja_alfa', 'EF', 2),
  ('eja_alfa', 'M', 3),  ('eja_alfa', 'C', 2),  ('eja_alfa', 'H', 2),
  ('eja_alfa', 'G', 1),  ('eja_alfa', 'ER', 1),
  ('eja_pos',  'LP', 4), ('eja_pos',  'A', 1),  ('eja_pos',  'EF', 2),
  ('eja_pos',  'M', 3),  ('eja_pos',  'C', 2),  ('eja_pos',  'H', 2),
  ('eja_pos',  'G', 1),  ('eja_pos',  'ER', 1),
  ('eja_alfa_pos', 'LP', 4), ('eja_alfa_pos', 'A', 1), ('eja_alfa_pos', 'EF', 2),
  ('eja_alfa_pos', 'M', 3),  ('eja_alfa_pos', 'C', 2), ('eja_alfa_pos', 'H', 2),
  ('eja_alfa_pos', 'G', 1),  ('eja_alfa_pos', 'ER', 1),
  -- M1 a M4 (20 períodos)
  ('eja_m1', 'LP', 4), ('eja_m1', 'LI', 1), ('eja_m1', 'A', 1),
  ('eja_m1', 'EF', 2), ('eja_m1', 'M', 4),  ('eja_m1', 'C', 3),
  ('eja_m1', 'H', 2),  ('eja_m1', 'G', 2),  ('eja_m1', 'ER', 1),
  ('eja_m2', 'LP', 4), ('eja_m2', 'LI', 1), ('eja_m2', 'A', 1),
  ('eja_m2', 'EF', 2), ('eja_m2', 'M', 4),  ('eja_m2', 'C', 3),
  ('eja_m2', 'H', 2),  ('eja_m2', 'G', 2),  ('eja_m2', 'ER', 1),
  ('eja_m1_m2', 'LP', 4), ('eja_m1_m2', 'LI', 1), ('eja_m1_m2', 'A', 1),
  ('eja_m1_m2', 'EF', 2), ('eja_m1_m2', 'M', 4),  ('eja_m1_m2', 'C', 3),
  ('eja_m1_m2', 'H', 2),  ('eja_m1_m2', 'G', 2),  ('eja_m1_m2', 'ER', 1),
  ('eja_m3', 'LP', 4), ('eja_m3', 'LI', 1), ('eja_m3', 'A', 1),
  ('eja_m3', 'EF', 2), ('eja_m3', 'M', 4),  ('eja_m3', 'C', 3),
  ('eja_m3', 'H', 2),  ('eja_m3', 'G', 2),  ('eja_m3', 'ER', 1),
  ('eja_m4', 'LP', 4), ('eja_m4', 'LI', 1), ('eja_m4', 'A', 1),
  ('eja_m4', 'EF', 2), ('eja_m4', 'M', 4),  ('eja_m4', 'C', 3),
  ('eja_m4', 'H', 2),  ('eja_m4', 'G', 2),  ('eja_m4', 'ER', 1)
) AS t(ano, sigla, p)
JOIN disciplinas d ON d.sigla = t.sigla;
